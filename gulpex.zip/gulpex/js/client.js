/**
* @author:banu
* file: client.js
*/

(function(){
	ShoppingCart.add("A");
	ShoppingCart.add("B");
	ShoppingCart.add("C");

	var items = ShoppingCart.get();
	items.forEach(function(item){
		console.log(item);
	});
})();