var Sequelize = require('sequelize');

var sequelize = new Sequelize('ge_node_db', 'root', 'Welcome123', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        idle: 10000
    }
});

var Customer = sequelize.define('customers', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true
    },
    firstName: Sequelize.STRING,
    lastName: Sequelize.STRING,
    gender: Sequelize.STRING,
    address: Sequelize.STRING
}, {
    timestamps: false
});

Customer.findById(3)
    .then(function(customer) {
        console.log(JSON.stringify(customer));
    })
    .catch(function(error) {
        console.log(error);
    });
