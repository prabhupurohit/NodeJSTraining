var Sequelize = require('sequelize'); //ORM

var sequelize = new Sequelize('ge_node_db', 'root', 'Welcome123', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        idle: 10000
    }
});

var Customer = sequelize.define('customers', {

    id: {
        type: Sequelize.INTEGER,
        primaryKey: true
    },
    firstName: Sequelize.STRING,
    lastName: Sequelize.STRING,
    gender: Sequelize.STRING,
    address: Sequelize.STRING
}, {
        timestamps:false 
});

var customer = Customer.build({
        "id": 5,
        "firstName": "Jhony",
        "lastName": "Depp",
        "gender": "male",
        "address": "Hollywood"
    });

customer.save().then(function() {
    console.log("Customer added!!!");
  });


