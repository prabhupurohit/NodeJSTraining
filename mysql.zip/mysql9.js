var Sequelize = require('sequelize');

var sequelize = new Sequelize('ge_node_db', 'root', 'Welcome123', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        idle: 10000
    }
});

var Customer = sequelize.define('customers', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true
    },
    firstName: Sequelize.STRING,
    lastName: Sequelize.STRING,
    gender: Sequelize.STRING,
    address: Sequelize.STRING
}, {
    timestamps: false
});

Customer.destroy({
        where: {
            id: 5
        }
    })
    .then(function(deletedRecords) {
        console.log(deletedRecords);
    })
    .catch(function(error) {
        console.log(error);
    });
