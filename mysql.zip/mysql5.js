var Sequelize = require('sequelize');

var sequelize = new Sequelize('ge_node_db', 'root', 'Welcome123', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        idle: 10000
    }
});

var Customer = sequelize.define('customers', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true
    },
    firstName: Sequelize.STRING,
    lastName: Sequelize.STRING,
    gender: Sequelize.STRING,
    address: Sequelize.STRING
}, {
    timestamps: false
});

Customer.findAll({})
    .then(function(customers) {
        console.log(JSON.stringify(customers));
    })
    .catch(function(error) {
        console.log(error);
    });
