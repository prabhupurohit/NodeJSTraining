var expect = require('chai').expect;
var request = require('request');

describe('color converter server tests', function(){

	it("should convert rgb to hex", function(done){
		var url = 'http://localhost:3000/rgbToHex?red=255&green=0&blue=0';
		request(url,function(err, response, body){
			expect(body).to.equal('ff0000');
			done();
		});
	});
});