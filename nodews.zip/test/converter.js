var converter = require('../app/converter');
var expect = require('chai').expect;

describe('color converter tests', function(){

	it("should convert rgb to hex", function(){
		var hex = converter.rgbToHex(239, 197, 164);
		expect(hex).to.equal('efc5a4');

		hex = converter.rgbToHex(34, 170, 38);
		expect(hex).to.equal('22aa26');

	});

	it("should convert hex to rgb", function(){
		var rgb = converter.hexToRgb('efc5a4');
		expect(rgb).to.deep.equal([239, 197, 164]);
		rgb = converter.hexToRgb('22aa26');
		expect(rgb).to.deep.equal([34, 170, 38]);
	});
});