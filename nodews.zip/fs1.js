/**
	Node JS supports IO operations
	using blocking and non-bloacking mode
*/

var fs = require("fs");

var content = fs.readFileSync("fs1.js"); //blocking mode

console.log(content.toString());