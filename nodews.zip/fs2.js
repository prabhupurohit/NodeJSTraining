/**
	Node JS supports IO operations
	using blocking and non-bloacking mode
*/

var fs = require("fs");

var content ="";

fs.readFile("fs1.js",function(err, chunk){
	content += chunk;
	console.log("INSIDE : " + content.toString());
}); //non-blocking mode

console.log("OUTSIDE : " + content.toString());