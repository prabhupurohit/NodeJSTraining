var Sequelize = require('sequelize');

var db = new Sequelize('ge_node_db', 'root', 'Welcome123', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        idle: 10000
    }
});

var Customer = db.define('customers', {
	timestamps:false,
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true
    },
    firstName: Sequelize.STRING,
    lastName: Sequelize.STRING,
    gender: Sequelize.STRING,
    address: Sequelize.STRING,

  	

});

// force: true will drop the table if it already exists
Customer.sync({ force: true }).then(function() {
    // Table created
    return Customer.create({
        "id": 5,
        "firstName": "Jhony",
        "lastName": "Depp",
        "gender": "male",
        "address": "Hollywood"
    });
});
