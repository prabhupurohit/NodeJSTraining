
Apache benchmark:
ab -n 2700 -c 90 http://localhost:3000/



Node JS Modules

NodeJS uses CommonJS module system

a.js

exports.one =  function() {
	two();
}

function two() {
	
}

second.js

var aobj = require('./a');

aobj();

----------


a.js

exports.one =  function() {
	two();
}

exports.two = function two() {
	
}

second.js

var aobj = require('./a').one;
var bobj = require('./a').two;

aobj();

--------------------------------
Node JS Application:
npm init --> bower init [ package.json ---> bower.json ]

npm install mocha --save-dev
npm install chai --save-dev
npm install request --save-dev


In Protractor:

browser.get("http://localhost:9000/");

Now using request:

request.get("http://localhost:9000/", function(err, response, body) {
	
});

Chai Assertion Library

Debug:
npm install -g node-inspector
npm install -g node-debug

node-debug color_server.js
------------

Running Mocha tests:

Create "test" folder parallel to "app" folder.
Create all test "js" files in "test" folder.

Execute Tests:
a) mocha --reporter spec
or
b) npm run test [ checks package.json "scritps" {"test" : "mocha --reporter spec"}]
and executes

other types of report
mocha --reporter spec
mocha --reporter dot
mocha --reporter list


https://github.com/johnpapa/angular-styleguide/blob/master/a1/README.md

https://github.com/dmytroyarmak/frontend-dev-resources


create database ge_node_db;
use ge_node_db;

create table customers (id int primary key, firstName varchar(50), lastName varchar(50), address varchar(150), gender varchar(10));

insert into customers values(1,'Ross','Geller','West Street', 'male');
insert into customers values(2,'Monica','Geller','West Street', 'female');
insert into customers values(3,'Rachel','Green','West Street', 'female');

mysql npm module is similar to JDBC/ADO.NET [ CRUD operations using SQL ]
sequilize is an ORM npm module similar to JPA [Hibernate]/ EntityFramework

mongod is npm module
mongoose is ORM

