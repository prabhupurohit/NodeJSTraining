var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'Welcome123',
  database : 'ge_node_db'
});

connection.connect();
 
connection.query('SELECT id, firstName, lastName, gender, address FROM customers', 
	function(err, rows, fields) {
  		if (err) throw err;
 		 console.log(rows);
});
 
connection.end();