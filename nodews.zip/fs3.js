/**
	Node JS supports IO operations
	using blocking and non-bloacking mode
*/

var fs = require("fs");

var content ="";

var stream = fs.createReadStream("fsdc1.js");  //event based 

stream.on('data', function(chunk) {
	console.log( chunk.toString());
});

stream.on('end', function(chunk) {
	console.log( "DONE");
});

stream.on('error', function(err, chunk) {
	console.log( "ERROR");
});