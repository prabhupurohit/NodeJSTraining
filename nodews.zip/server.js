/**
	HTTP_SERVER
*/

var http = require('http');
var fs = require('fs');

var server = http.createServer(function(request, response) {

    var stream = fs.createReadStream("fs1.js"); //event based 

    stream.on('data', function(chunk) {
      response.write(chunk.toString());
    });

    stream.on('end', function(chunk) {
       response.end();
    });
});

server.listen(3000, function(){
	console.log("Server Started on http://localhost:3000 ");
});


