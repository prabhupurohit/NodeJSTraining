var mongoose = require('mongoose');

var SalesSchema = new mongoose.Schema({
     category: String,
     product:String,
     sales: Number,
     quarter: Number
});

var Sales = mongoose.model("sales",SalesSchema);

module.exports = Sales;