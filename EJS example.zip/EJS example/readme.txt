copy customerDao.js into dao folder
copy customer.js into routes folder
copy customer.ejs into views folder